﻿namespace Strings;

public class UrlParser
{
    public  void ParseURL(string url, out string protocol, out string server, out string resource)
    {
        protocol = "";
        resource = "";

        // Check if the URL starts with a protocol
        int protocolSeparatorIndex = url.IndexOf("://");
        if (protocolSeparatorIndex != -1)
        {
            protocol = url.Substring(0, protocolSeparatorIndex);
            url = url.Substring(protocolSeparatorIndex + 3);
        }

        // Find the server
        int serverEndIndex = url.IndexOf("/");
        if (serverEndIndex != -1)
        {
            server = url.Substring(0, serverEndIndex);
            resource = url.Substring(serverEndIndex + 1);
        }
        else
        {
            server = url;
        }
    }
}