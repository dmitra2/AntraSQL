﻿using System;
using Strings;

namespace ExcerciseChapter02
{
    class Program
    {
        static void Main(string[] args)
        {   
            //String Reverser
            StrReverse s = new StrReverse();
            s.ReversingString();
            
            //Word Reverser
            WordReverser w = new WordReverser();
            w.wordReverserMethod();
            
            //PalindromeExtractor
            // Given text
            string text = "Hi,exe? ABBA! Hog fully a string: ExE. Bob";

            // Extract palindromes from the text
            List<string> palindromes = PalindromeExtractor.ExtractPalindromes(text);

            // Print the palindromes on the console
            Console.WriteLine(string.Join(", ", palindromes));
            
            //URL parser
            string[] urls = {
                "https://www.apple.com/iphone",
                "ftp://www.example.com/employee",
                "https://google.com",
                "www.apple.com"
            };

            UrlParser up = new UrlParser();

            foreach (string url in urls)
            {
                up.ParseURL(url, out string protocol, out string server, out string resource);
                Console.WriteLine($"URL: {url}");
                Console.WriteLine($"Protocol: {(string.IsNullOrEmpty(protocol) ? "(none)" : protocol)}");
                Console.WriteLine($"Server: {server}");
                Console.WriteLine($"Resource: {(string.IsNullOrEmpty(resource) ? "(none)" : resource)}");
                Console.WriteLine();
            }
        }
    }
}