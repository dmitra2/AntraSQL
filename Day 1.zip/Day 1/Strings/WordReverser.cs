﻿namespace Strings;

using System;
using System.Text.RegularExpressions;

class WordReverser
{
    public void wordReverserMethod()
    {
        // Input sentences
        string sentence = "C# is not C++, and PHP is not Delphi!";
        Console.WriteLine("Original sentence: " + sentence);

        // Reverse the words in the sentence
        string reversedSentence = ReverseWords(sentence);

        // Output reversed sentence
        Console.WriteLine("Reversed sentence: " + reversedSentence);
    }

    static string ReverseWords(string sentence)
    {
        // Define separators between words
        char[] separators = { ' ', '.', ',', ':', ';', '=', '(', ')', '&', '[', ']', '"', '\'', '\\', '/', '!', '?', };

        // Split the sentence into words
        string[] words = sentence.Split(separators, StringSplitOptions.RemoveEmptyEntries);

        // Reverse the array of words
        Array.Reverse(words);

        // Find and replace the words in the original sentence with the reversed words
        int wordIndex = 0;
        return Regex.Replace(sentence, @"\w+", m => words[wordIndex++]);
    }
}
