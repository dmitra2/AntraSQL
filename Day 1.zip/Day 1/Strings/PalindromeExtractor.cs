﻿namespace Strings;

public class PalindromeExtractor
{
    public static List<string> ExtractPalindromes(string text)
    {
        List<string> palindromes = new List<string>();

        // Split the text into words and remove punctuation
        string[] words = text.Split(new[] { ' ', ',', '.', ':', '!', '?', ';' }, StringSplitOptions.RemoveEmptyEntries);

        // Check each word for palindrome and add it to the list if it's a palindrome
        foreach (string word in words)
        {
            string normalizedWord = NormalizeWord(word);
            if (IsPalindrome(normalizedWord))
            {
                palindromes.Add(normalizedWord);
            }
        }

        // Remove duplicates and sort the list
        palindromes = palindromes.Distinct().OrderBy(p => p).ToList();

        return palindromes;
    }

    private static string NormalizeWord(string word)
    {
        return word.ToLower();
    }

    private static bool IsPalindrome(string word)
    {
        for (int i = 0; i < word.Length / 2; i++)
        {
            if (word[i] != word[word.Length - i - 1])
            {
                return false;
            }
        }
        return true;
    }
}