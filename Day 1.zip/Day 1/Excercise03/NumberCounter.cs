﻿using System;

namespace Exercise03
{
    public class NumberCounter
    {
        public void CountNumbers(int max)
        {
            for (byte i = 0; i < max; i++)
            {
                Console.WriteLine(i);

                // Check if i is at the maximum value for byte
                if (i == byte.MaxValue)
                {
                    Console.WriteLine("Warning: Reached maximum value for byte.");
                    break;
                }
            }
        }
    }
}