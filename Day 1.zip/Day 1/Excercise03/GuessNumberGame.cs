﻿using System;
namespace Excercise03;

public class GuessNumberGame
{
    public void guessNumber()
    {
        int generatedNumber = new Random().Next(3) + 1;
        Console.WriteLine(generatedNumber);
        Console.WriteLine("Enter your guess number between 1 and 3");
        int userGuessNumber;
        if(int.TryParse(Console.ReadLine(), out userGuessNumber )) {
            if (userGuessNumber < 0 || userGuessNumber > 4)
            {
                Console.WriteLine("Enter your number in range 1 and 3");
            }
            else
            {
                if (generatedNumber == userGuessNumber)
                {
                    Console.WriteLine(
                        $"Congrats!!.your guessnumber {userGuessNumber}  matches with computer number {generatedNumber}. " +
                        $"You guessed the correct number");
                }
                else if (userGuessNumber < generatedNumber)
                {
                    Console.WriteLine(
                        $"your guess number {userGuessNumber} is lower than computer generated number {generatedNumber}");
                }
                else
                {
                    Console.WriteLine(
                        $"your guess number {userGuessNumber} is higher than computer generated number {generatedNumber}");
                }
            }
        }
        else
        {
            Console.WriteLine("We dont accept String value. Enter integer values");
        }
    }
}