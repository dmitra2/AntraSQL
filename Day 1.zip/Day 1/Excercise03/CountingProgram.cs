﻿namespace Excercise03;

public class CountingProgram
{
    public void iteration()
    {
        // Iterate through different increments
        for (int increment = 1; increment <= 4; increment++) {
            Console.Write("Increment by " + increment + "s: ");
            // Iterate from 0 to 24 with the current increment
            for (int i = 0; i <= 24; i += increment) {
                Console.Write(i + " ");
            }
            Console.WriteLine(); // Move to the next line for the next increment
        }
    }
}