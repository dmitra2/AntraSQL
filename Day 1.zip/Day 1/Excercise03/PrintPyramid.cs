﻿namespace Excercise03;

public class PrintPyramid
{
    public void printStar()
    {
        int rows = 5; // Change the number of rows as needed
        
        // Outer loop for each row
        for (int i = 0; i < rows; i++)
        {
            // Inner loop for spaces before stars
            for (int j = 0; j < rows - i - 1; j++)
            {
                Console.Write(" ");
            }

            // Inner loop for printing stars
            for (int k = 0; k < 2 * i + 1; k++)
            {
                Console.Write("*");
            }

            // Move to the next line after each row
            Console.WriteLine();
        }
    }
}