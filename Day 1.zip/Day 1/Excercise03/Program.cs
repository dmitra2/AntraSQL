﻿// See https://aka.ms/new-console-template for more information

using System;
using Exercise03;

namespace Excercise03
{
    class Program
    {
        static void Main(string[] args)
        {
            //FizzBuzz checker
            FizzBuzzCheck fb = new FizzBuzzCheck();
            fb.fizzBuzzChecker();
            Console.WriteLine("--------------------------------------------------------------------");
            
            //NumberCounter Checker
            Console.WriteLine("Enter the max value of the integer");
            int a = int.Parse(Console.ReadLine());
            NumberCounter nc = new NumberCounter();
            nc.CountNumbers(a);
            Console.WriteLine("--------------------------------------------------------------------");
            
            //GuessNumber 
            GuessNumberGame g = new GuessNumberGame();
            g.guessNumber();
            Console.WriteLine("--------------------------------------------------------------------");
            
            //Pyramid print
            PrintPyramid p = new PrintPyramid();
            p.printStar();
            Console.WriteLine("--------------------------------------------------------------------");
            
            //Print According to birth date 
            BirthDateCalculator b = new BirthDateCalculator();
            b.birthDateCalculation();
            Console.WriteLine("--------------------------------------------------------------------");
            
            //Greeting according to day time
            GreetingAccordingToTime g1 = new GreetingAccordingToTime();
            g1.getCurrentHour();
            Console.WriteLine("--------------------------------------------------------------------");
            
            //Counting program on iteration
            CountingProgram cp = new CountingProgram();
            cp.iteration();
            Console.WriteLine("--------------------------------------------------------------------");
        }
    }
}
