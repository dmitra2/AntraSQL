﻿namespace Excercise03;

public class GreetingAccordingToTime
{
    public void getCurrentHour()
    {
        // Get the current time
        DateTime currentTime = DateTime.Now;

        // Extract the hour from the current time
        int hour = currentTime.Hour;

        // Greet the user based on the time of day
        if (hour >= 5 && hour < 12) {
            Console.WriteLine("Good Morning!");
        }
        if (hour >= 12 && hour < 18) {
            Console.WriteLine("Good Afternoon!");
        }
        if (hour >= 18 && hour < 22) {
            Console.WriteLine("Good Evening!");
        }
        if (hour >= 22 || hour < 5) {
            Console.WriteLine("Good Night!");
        }
    }
}