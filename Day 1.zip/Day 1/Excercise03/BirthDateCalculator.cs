﻿namespace Excercise03;

public class BirthDateCalculator
{
    public void birthDateCalculation()
    {
        // Define the birth date
        DateTime birthDate = new DateTime(1994, 12, 07); 

        // Calculate the number of days since birth
        TimeSpan age = DateTime.Today - birthDate;
        int daysOld = (int)age.TotalDays;

        // Output the number of days old
        Console.WriteLine("You are {0} days old.", daysOld);

        // Calculate the date of the next 10,000-day anniversary
        int daysToNextAnniversary = 10000 - (daysOld % 10000);
        DateTime nextAnniversary = DateTime.Today.AddDays(daysToNextAnniversary);

        // Output the date of the next anniversary
        Console.WriteLine("Your next 10,000-day anniversary will be on {0:MMMM dd, yyyy}.", nextAnniversary);
    }
}