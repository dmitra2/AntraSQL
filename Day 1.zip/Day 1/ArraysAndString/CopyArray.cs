﻿using System;
namespace ArraysAndString;

public class CopyArray
{
    public void copyExistingArray()
    {
        // Create an initial array with 10 items
        int[] originalArray = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

        // Print the contents of the original array
        Console.WriteLine("Original Array:");
        PrintArray(originalArray);

        // Create a new array with the same length as the original array
        int[] copiedArray = new int[originalArray.Length];

        // Copy values from the original array to the new array
        for (int i = 0; i < originalArray.Length; i++)
        {
            copiedArray[i] = originalArray[i];
        }

        // Print the contents of the copied array
        Console.WriteLine("\nCopied Array:");
        PrintArray(copiedArray);
    }

    // Method to print the contents of an array
    static void PrintArray(int[] array)
    {
        foreach (int item in array)
        {
            Console.Write(item + " ");
        }
        Console.WriteLine();
    }
}