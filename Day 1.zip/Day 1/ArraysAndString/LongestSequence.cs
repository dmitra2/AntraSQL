﻿namespace ArraysAndString;

public class LongestSequence
{
    public void longestSequenceofArray()
    {
        // Read the input array of integers
        Console.WriteLine("Enter the array of integers separated by spaces:");
        int[] numbers = Console.ReadLine()
            .Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(int.Parse)
            .ToArray();

        // Find the longest sequence of equal elements
        int longestStartIndex = 0;
        int longestLength = 1;

        int currentStartIndex = 0;
        int currentLength = 1;

        for (int i = 1; i < numbers.Length; i++)
        {
            if (numbers[i] == numbers[i - 1])
            {
                currentLength++;
            }
            else
            {
                currentStartIndex = i;
                currentLength = 1;
            }

            if (currentLength > longestLength)
            {
                longestLength = currentLength;
                longestStartIndex = currentStartIndex;
            }
        }

        // Output the longest sequence
        Console.WriteLine("The longest sequence of equal elements:");
        for (int i = longestStartIndex; i < longestStartIndex + longestLength; i++)
        {
            Console.Write(numbers[i] + " ");
        }
        Console.WriteLine();
    }
}