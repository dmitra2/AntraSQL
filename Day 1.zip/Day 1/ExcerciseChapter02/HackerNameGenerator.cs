﻿namespace ExcerciseChapter02;

public class HackerNameGenerator
{
    public void getHackerName()
    {
        // Ask the user for their favorite color
        Console.WriteLine("What is your favorite color?");
        string favoriteColor = Console.ReadLine();

        // Ask the user for their astrology sign
        Console.WriteLine("What is your astrology sign?");
        string astrologySign = Console.ReadLine();

        // Ask the user for their street address number
        Console.WriteLine("What is your street address number?");
        string addressNumberInput = Console.ReadLine();

        // Convert the address number input to an integer
        int addressNumber;
        if (!int.TryParse(addressNumberInput, out addressNumber))
        {
            Console.WriteLine("Invalid address number. Please enter a valid number.");
            return;
        }

        // Generate the hacker name
        string hackerName = $"{favoriteColor}{astrologySign}{addressNumber}";

        // Display the hacker name to the user
        Console.WriteLine($"Your hacker name is {hackerName}.");
    }
}