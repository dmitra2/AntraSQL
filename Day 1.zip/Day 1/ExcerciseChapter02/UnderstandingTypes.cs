﻿namespace ExcerciseChapter02;

public class UnderstandingTypes
{
    public void getTypes()
    {
        Console.WriteLine("Data Type    | Bytes | Min Value           | Max Value");
        Console.WriteLine("----------------------------------------------");

        Console.WriteLine($"sbyte        | {sizeof(sbyte),-5} | {sbyte.MinValue,-20} | {sbyte.MaxValue}");
        Console.WriteLine($"byte         | {sizeof(byte),-5} | {byte.MinValue,-20} | {byte.MaxValue}");
        Console.WriteLine($"short        | {sizeof(short),-5} | {short.MinValue,-20} | {short.MaxValue}");
        Console.WriteLine($"ushort       | {sizeof(ushort),-5} | {ushort.MinValue,-20} | {ushort.MaxValue}");
        Console.WriteLine($"int          | {sizeof(int),-5} | {int.MinValue,-20} | {int.MaxValue}");
        Console.WriteLine($"uint         | {sizeof(uint),-5} | {uint.MinValue,-20} | {uint.MaxValue}");
        Console.WriteLine($"long         | {sizeof(long),-5} | {long.MinValue,-20} | {long.MaxValue}");
        Console.WriteLine($"ulong        | {sizeof(ulong),-5} | {ulong.MinValue,-20} | {ulong.MaxValue}");
        Console.WriteLine($"float        | {sizeof(float),-5} | {float.MinValue,-20} | {float.MaxValue}");
        Console.WriteLine($"double       | {sizeof(double),-5} | {double.MinValue,-20} | {double.MaxValue}");
        Console.WriteLine($"decimal      | {sizeof(decimal),-5} | {decimal.MinValue,-20} | {decimal.MaxValue}");
    }
}