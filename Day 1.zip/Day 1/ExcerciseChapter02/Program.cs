﻿using System;

namespace ExcerciseChapter02
{
    class Program
    {
        static void Main(string[] args)
        {   
            // get hacker name 
            HackerNameGenerator hng = new HackerNameGenerator();
            hng.getHackerName();
            
            // get Types
            UnderstandingTypes us = new UnderstandingTypes();
            us.getTypes();
            
            //get information of entred century
            CenturyConversion cc = new CenturyConversion();
            cc.centuryInfo();
        }
    }
}